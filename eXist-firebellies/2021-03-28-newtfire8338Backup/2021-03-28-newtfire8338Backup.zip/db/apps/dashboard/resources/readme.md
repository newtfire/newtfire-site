# Resources Dir

The place to put your local JS, CSS and other stuff
