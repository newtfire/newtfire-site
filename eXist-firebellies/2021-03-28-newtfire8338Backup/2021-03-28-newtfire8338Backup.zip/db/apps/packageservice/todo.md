# todo

* update readme to reflect changed format (JSON)